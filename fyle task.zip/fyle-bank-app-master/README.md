Angular CLI 7.1.4

Angular 7.1.1

Node 8.9.4

Unzip the project, go to main folder and run following commands to run in development mode

To install all the dependencies npm install

Start the project ng serve

open at localhost:4200


Run the project in production mode, 

npm install http-server -g

run command

http-server

open at localhost:8080