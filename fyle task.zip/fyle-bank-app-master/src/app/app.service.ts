import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams, HttpResponse } from '@angular/common/http';
import { Observable, from } from 'rxjs';
import 'rxjs/add/operator/do';
import 'rxjs/add/observable/fromPromise';
import { TransferState } from '@angular/platform-browser';


@Injectable({
  providedIn: 'root'
})
export class AppService {

  constructor(private httpClient : HttpClient, protected transferState: TransferState) { }


  getBanks(city):Observable<any>{
    // get data checks if requested url already been loaded
    // if yes get it from cache
    // if no save it into cache and return the response
    return this.getData('get', `https://vast-shore-74260.herokuapp.com/banks?city=${city}`, (method: string, url: string) => {
      // get data return http client get request if api is called first time.
      return this.httpClient.get(url);
    });
  }

  private getData(
    method: string,
    uri: string | Request,
    callback: (method: string, uri: string | Request) => Observable<any>) {

    let url = uri;

    if (typeof uri !== 'string') {
      url = uri.url;
    }

    const key = url + '';
    try {
      let resolvedData = this.resolveData(key);
      if(resolvedData){
        this.deleteCache(key);
      }
      return resolvedData;

    } catch (e) {
      return callback(method, key)
      .do(data => {
        this.setCache(key, data);
      });
    }
  }

  private resolveData(key: string) {
    const data = this.getFromCache(key);

    if (!data) {
      throw new Error();
    }

    return from(Promise.resolve(data));
  }

  private setCache(key, data) {
    return this.transferState.set(key, data);
  }
  private deleteCache(key) {
    return this.transferState.remove(key);
  }

  private getFromCache(key): any {
    return this.transferState.get(key, null);
  }
}
