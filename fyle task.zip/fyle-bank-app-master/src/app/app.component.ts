import { Component, OnInit, Pipe, PipeTransform } from '@angular/core';
import { AppService } from './app.service';
import { interval } from 'rxjs';
import { exhaustMap, map, take } from 'rxjs/operators';

class Bank {
	ifsc      : string;
	bank_id   : number;
	branch    : string;
	address   : string;
	city      : string;
	district  : string;
	state     : string;
	bank_name : string;
}

@Pipe({
  name: 'filter'
})
export class FilterPipe implements PipeTransform {
	  
	transform(items: any[], searchText: string): any[] {
		
		if(!items) return [];
		
		if(!searchText) return items;
		
		searchText = searchText.toLocaleLowerCase();
		return items.filter( item => {
			for (let key in item ) {
				if((""+item[key]).toLocaleLowerCase().includes(searchText)){
					return true;
				}
			}
			return false;
		});
   	}
}

@Component({
	selector: 'app-root',
	templateUrl: './app.component.html',
	styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit{
	cities : string[] = ['MUMBAI', 'BANGALORE', 'GOA', 'PUNE', 'DELHI'];
	city   : string = this.cities[0]; 
	searchText : string;
	banks  : Bank[] = [];
	maxSize : number = 0;
	perpage : number = 10;
	currentPage : number = 1;
	isLoading : 0 | 1 | -1;

	constructor(private _appService : AppService){}

	ngOnInit(){
    	this.getBanks(this.city);
	}

 	getBanks(city){
		this.banks = [];
		this.currentPage = 1;
		this.maxSize = 0;
		this.isLoading = 0;

		// this._appService.getBanks(city).pipe(take(1000)).subscribe(response => {
			// this.banks = response;
			// this.maxSize = Math.ceil(this.banks.length / this.perpage);
			// this.isLoading = 1;
		// }, (error)=>{
			// this.isLoading = -1;
		// });

		const $bankObservable = this._appService.getBanks(city);
		const exhaustHub = $bankObservable.pipe(
			exhaustMap(res => {
				this.banks = res;
				this.maxSize = Math.ceil(this.banks.length / this.perpage);
				this.isLoading = 1;
				return res;
			})
		).subscribe(response => {
			return response;
		}, (error)=>{
			this.isLoading = -1;
		});
	}

	goPage(dir){
		if(dir == 'prev'){
			this.currentPage > 1 ? this.currentPage-- : this.currentPage;
		}
		if(dir == 'next'){
			this.currentPage < this.maxSize ? this.currentPage++ : this.currentPage;
		}
	}

	getMaxSize(length){
		return Math.ceil(length / this.perpage);
	}
}
